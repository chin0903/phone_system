<?php
	class phone_list extends CI_Controller{

		public function search($page = 'home') {
			$data['title'] = "Search";

			$data['phone'] = $this->phone_model->get_phone();
			if(empty($data['phone'])){
				show_404();
			}

			$this->load->view('templates/header');
			$this->load->view('phone_list/search', $data);
			$this->load->view('templates/footer');
		}

		public function view($id = NULL){
			$data['phone'] = $this->phone_model->get_phone($id);

			if(empty($data['phone'])){
				show_404();
			}
			$data['phone']['title'] = "Phone details";
			$this->load->view('templates/header');
			$this->load->view('phone_list/view', $data);
			$this->load->view('templates/footer');
		}

		public function add(){
			$data['title'] = "New Phone Book";
			$this->load->view('templates/header');
			$this->load->view('phone_list/add', $data);
			$this->load->view('templates/footer');
			
		}

		public function edit($id) {
			$data['phone'] = $this->phone_model->get_phone($id);

			if(empty($data['phone'])){
				show_404();
			}

			$data['phone']['title'] = "Edit Phone Book";
			$this->load->view('templates/header');
			$this->load->view('phone_list/edit', $data);
			$this->load->view('templates/footer');
		}

		public function add_record(){
		    $postData = $this->input->post();
		    $this->phone_model->add_profile($postData);
		 }

		public function edit_record(){

		    $postData = $this->input->post();
		    $this->phone_model->edit_profile($postData);
		 }

		 public function delete_record() {

		 	$postData = $this->input->post();
			$this->phone_model->delete_profile($postData);
		}
	}