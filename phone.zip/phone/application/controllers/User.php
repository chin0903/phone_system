<?php
	class User extends CI_Controller{
		public function register(){
			$data['title'] = "Register";

			$this->load->view("templates/header");
			$this->load->view("user/register", $data);
			$this->load->view("templates/footer");

		}

		public function login(){
			$data['title'] = "Login";

			$this->load->view("templates/header");
			$this->load->view("user/login", $data);
			$this->load->view("templates/footer");

		}

		public function add_user(){
		    $postData = $this->input->post();
		    $check = $this->user_model->check_duplicate_user($postData);

		    if($check == 0){
		    	$this->user_model->add_user($postData);
		    	echo "Successful";
		    }else{
		    	echo "Duplicate";
		    }
		    
		}

		public function check_login(){
		    $postData = $this->input->post();
		    $login_result = $this->user_model->login_user($postData);
		    if(sizeof($login_result) > 0 ){
		    	$this->session->set_userdata('user_name', $login_result[0]['name']);
		    	$this->session->set_userdata('user_id', $login_result[0]['user_id']);
		    }
		    
		    echo json_encode($login_result);
		}

		public function logout(){
			$this->session->unset_userdata('user_name');
			$this->session->unset_userdata('user_id');
		    redirect('user/login');
		}
	}