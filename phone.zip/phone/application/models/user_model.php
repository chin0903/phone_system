<?php
	class User_model extends CI_Model{
		public function __construct(){
			$this->load->database();
		}
		
		public function check_duplicate_user($post) {
			$login = array(
				'user_id' => $post['user_id'],
			);

			$query = $this->db->get_where('login', $login);
			return $query->num_rows();
		}

		public function add_user($post) {

			$data = array(
				'name' => $post['name'],
				'user_id' => $post['user_id'],
				'password' => $post['password'],
			);

			return $this->db->insert('login', $data);
		}

		public function login_user($post) {

			$login = array(
				'user_id' => $post['user_id'],
				'password' => $post['password'],
			);

			$query = $this->db->get_where('login', $login);
			$current_date = date("Y-m-d H:i:s");
			if($query->num_rows() > 0) {
				$login_time = array(
					'last_login_time' => $current_date,
				);

				$this->db->where('user_id', $post['user_id']);
				$this->db->update('login', $login_time);
			}

			return $query->result_array();
		}
	}