<?php
	class Phone_model extends CI_Model{
		public function __construct(){
			$this->load->database();
		}
		
		public function get_phone($id = "") {

			if($id != "") {
				$query = $this->db->get_where('profile', array('id' => $id));
				return $query->row_array();
			}

			$query = $this->db->get('profile');
			return $query->result_array();
		}

		public function add_profile($post) {

			$data = array(
				'name' => $post['name'],
				'address' => $post['address'],
				'phone_no' => $post['phone_no'],
				'email' => $post['email'],
				'gender' => $post['gender'],
			);

			return $this->db->insert('profile', $data);
		}

		public function edit_profile($post){
			$data = array(
				'name' => $post['name'],
				'address' => $post['address'],
				'phone_no' => $post['phone_no'],
				'email' => $post['email'],
				'gender' => $post['gender'],
			);
			$this->db->where('id', $post['id']);
			return $this->db->update('profile', $data);
		}

		public function delete_profile($post){
			$this->db->where('id', $post['id']);
			return $this->db->delete('profile');
		}
	}