<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['phone_list/delete_record'] = "phone_list/delete_record";
$route['phone_list/edit_record'] = "phone_list/edit_record";
$route['phone_list/add_record'] = "phone_list/add_record";
$route['phone_list/add'] = "phone_list/add";
$route['phone_list'] = "phone_list/search";
$route['phone_list/(:any)'] = 'phone_list/view/$1';
$route['default_controller'] = 'pages/view';
$route['(:any)'] = 'pages/view/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
