<script>
$(document).ready( function () {
    $('#phone_list').DataTable();
} );
</script>

<table id="phone_list" class="display">
    <thead>
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Phone No</th>
            <th>Email</th>
            <th>Gender</th>
            <th>View</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 0;
    foreach($phone as $rw) {
        $no++;
    ?>
    <tr>
        <td><?= $no ?></td>
        <td><?= $rw['name']; ?></td>
        <td><?= $rw['phone_no']; ?></td>
        <td><?= $rw['email']; ?></td>
        <td><?php 
        if($rw['gender'] == "1" ){
            echo "Male";
        }elseif($rw['gender'] == "2") {
            echo "Female";
        }else{
            echo "Unknown";
        } 
        ?></td>
        <td><a class="btn btn-default" href="<?php echo site_url('/phone_list/' . $rw['id']); ?>">Read More</a></td>
    </tr>
    <?php
        }
    ?>
    </tbody>

</table>


