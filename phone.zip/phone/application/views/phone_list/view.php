<h2><?php echo $phone['title']; ?></h2>

<table class="table">
<tr>
<th>Title</th>
<th>Details</th>
</tr>

<tr>
<td>Name</td>
<td><?= $phone['name']; ?></td>
</tr>

<tr>
<td>Address</td>
<td><?= $phone['address']; ?></td>
</tr>

<tr>
<td>Phone No</td>
<td><?= $phone['phone_no']; ?></td>
</tr>

<tr>
<td>Email</td>
<td><?= $phone['email']; ?></td>
</tr>

<tr>
<td>Gender</td>
<td><?php 
if($phone['gender'] == "1") {
	echo "Male";
}elseif($phone['gender'] == "2"){
	echo "Female";
} 
?></td>
</tr>

</table>

<hr>
<a class="btn btn-default pull-left" href="edit/<?php echo $phone['id']; ?>">Edit</a>&nbsp;
<input type="button" class="btn btn-danger" id="btn_delete" name="btn_delete" value="Delete" />


<!-- Question Modal -->
<div class="modal fade" id="questionModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        Information
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div id="question_body" class="modal-body">
      </div>
      <div class="modal-footer">
        <button id="btn_modal_yes" type="button" class="btn btn-secondary" >Yes</button>
        <button id="btn_modal_no" type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function(){
	$("#btn_delete").click(function(){


		$("#question_body").html("Are you sure delete this record?");
	    $("#questionModal").modal("show");
	    $("#btn_modal_yes").click(function(){
	    	$("#questionModal").modal("hide");
	        $.ajax({
			  type: "POST",
			  url: '<?=base_url()?>index.php/phone_list/delete_record',
			  data: {
			  	"id" : "<?= $phone['id']; ?>",
			  },
			  error: function() {
		              alert('Something is wrong');
		       },
			  success: function(data) {

			  	$(".modal-body").html("Record delete successfully");
		        $("#messageModal").modal("show");
		        $("#btn_message").click(function(){
		            window.location.href = "<?=base_url()?>phone_list";
		        });
			  }
			});
	    });
	});
});
</script>