<h2><?= $phone['title'] ?></h2>
<?php echo form_open('phone_list/edit_record'); ?>
  <div class="form-group">
    <label>Name</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Ali" value="<?= $phone['name']; ?>">
  </div>
  <div class="form-group">
    <label>Address</label>
    <textarea id="address" class="form-control" name="address" placeholder="Address"><?= $phone['address']; ?></textarea>
  </div>
   <div class="form-group">
    <label>Phone No</label>
    <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="011-6663333" onkeypress="return isNumberKey(event);" maxlength="12" value="<?= $phone['phone_no']; ?>" >
  </div>
  <div class="form-group">
    <label>Email</label>
    <input type="text" class="form-control" id="email" name="email" placeholder="example@example.com" value="<?= $phone['email']; ?>" >
  </div>
  <div class="form-group">
    <label>Gender</label>
    <select id="gender" name="gender" class="form-control">
    	<option value="" hidden selected>Please Select</option>
    	<option value="1" <?= ($phone['gender'] == "1" ? "selected" : "") ?> >Male</option>
    	<option value="2" <?= ($phone['gender'] == "2" ? "selected" : "") ?> >Female</option>
    </select>
  </div>
  <input type="button" id="btn_update" name="btn_update" class="btn btn-default" value="Update" />
  <input type="reset" id="btn_reset" class="btn btn-default" value="Reset" />
</form>

<script>
$(document).ready(function(){
  $("#btn_update").click(function(){
    var chk_error = false;
  	$(".error-text").removeClass("error-text");
  	if($("#name").val() == ""){
  		$("#name").addClass("error-text");
      chk_error = true;
  	}
  	if($("#address").val() == ""){
  		$("#address").addClass("error-text");
      chk_error = true;
  	}
  	if($("#phone_no").val() == ""){
  		$("#phone_no").addClass("error-text");
      chk_error = true;
  	}
  	if($("#email").val() == ""){
  		$("#email").addClass("error-text");
      chk_error = true;
  	}
  	if($("#gender").val() == ""){
  		$("#gender").addClass("error-text");
      chk_error = true;
  	}

    if(chk_error == false) {
      $.ajax({
        type: "POST",
        url: '<?=base_url()?>index.php/phone_list/edit_record',
        data: {
          "id" : "<?= $phone['id']; ?>",
          "name" : $("#name").val(),
          "address" : $("#address").val(),
          "phone_no" : $("#phone_no").val(),
          "email" : $("#email").val(),
          "gender" : $("#gender").val(),
        },
        error: function() {
           $(".modal-body").html("Something is wrong");
           $("#messageModal").modal("show");
        },
        success: function(data) {

          $(".modal-body").html("Record update successfully");
          $("#messageModal").modal("show");
          $("#btn_message").click(function(){
            window.location.href = "<?=base_url()?>phone_list";
          });
        }
      });
    }
    
  });

});

function isNumberKey(evt)
{
  var charCode = (evt.which) ? evt.which : event.keyCode;
 console.log(charCode);
    if (charCode != 46 && charCode != 45 && charCode > 31
    && (charCode < 48 || charCode > 57))
     return false;

  return true;
}
</script>