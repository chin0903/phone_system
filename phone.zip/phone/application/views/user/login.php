<h2><?= $title; ?></h2>
<?php echo form_open("user/login"); ?>
	<div class="form-group">
		<label>User ID</label>
		<input type="text" class="form-control" id="user_id" name="user_id" />
	</div> 
	<div class="form-group">
		<label>Password</label>
		<input type="password" class="form-control" id="password" name="password" />
	</div> 

	<input type="button" id="btn_login" name="btn_login" class="btn btn-default" value="Login" />
  <input type="reset" id="btn_reset" class="btn btn-default" value="Reset" />
  <br><br>
  <a href="<?php echo base_url(); ?>user/register" >Click Here To Register</a>
<?php echo form_close(); ?>

<script>
$(document).ready(function(){
  $("#btn_login").click(function(){
  	var chk_error = false;
  	$(".error-text").removeClass("error-text");
  	if($("#user_id").val() == ""){
  		$("#user_id").addClass("error-text");
      chk_error = true;
  	}
  	if($("#password").val() == ""){
  		$("#password").addClass("error-text");
      chk_error = true;
  	}

  	if(chk_error == false) {
  		$.ajax({
		  type: "POST",
		  url: '<?=base_url()?>index.php/user/check_login',
		  data: {
		  	"user_id" : $("#user_id").val(),
		  	"password" : $("#password").val(),
		  },
		  dataType: 'json',
		  error: function() {
	            $(".modal-body").html("Something is wrong");
		  		$("#messageModal").modal("show");
	       },
		  success: function(data) {
		  	if(data.length > 0) {
		  		$(".modal-body").html("Login successfully");
		  		$("#messageModal").modal("show");
		  		$("#btn_message").click(function(){
		  			window.location.href = "<?=base_url()?>phone_list";
		  		});
		  		
		  	}else{
		  		$(".modal-body").html("Invalid User ID and Password");
		  		$("#messageModal").modal("show");
		  	}
		  	
		  }
		});
  	}
    
  });

});
</script>