<h2><?= $title; ?></h2>

<?php echo form_open("user/register"); ?>
	<div class="form-group">
		<label>Name</label>
		<input type="text" class="form-control" id="name" name="name" />
	</div> 
	<div class="form-group">
		<label>User ID</label>
		<input type="text" class="form-control" id="user_id" name="user_id" />
	</div> 
	<div class="form-group">
		<label>Password</label>
		<input type="password" class="form-control" id="password" name="password" />
	</div> 
	<div class="form-group">
		<label>Confirm Password</label>
		<input type="password" class="form-control" id="password2" name="password2" />
	</div>

	<input type="button" id="btn_add" name="btn_add" class="btn btn-default" value="Submit" />
  <input type="reset" id="btn_reset" class="btn btn-default" value="Reset" /> 
<?php echo form_close(); ?>

<script>
$(document).ready(function(){
  $("#btn_add").click(function(){
  	var chk_error = false;
  	$(".error-text").removeClass("error-text");
  	if($("#name").val() == ""){
  		$("#name").addClass("error-text");
      chk_error = true;
  	}
  	if($("#user_id").val() == ""){
  		$("#user_id").addClass("error-text");
      chk_error = true;
  	}
  	if($("#password").val() == ""){
  		$("#password").addClass("error-text");
      chk_error = true;
  	}
  	if($("#password2").val() == ""){
  		$("#password2").addClass("error-text");
      chk_error = true;
  	}

  	if($("#password2").val() != $("#password").val()) {
  		$("#password").addClass("error-text");
  		$("#password2").addClass("error-text");
  		chk_error = true;
  	}


  	if(chk_error == false) {
  		$.ajax({
		  type: "POST",
		  url: '<?=base_url()?>index.php/user/add_user',
		  data: {
		  	"name" : $("#name").val(),
		  	"user_id" : $("#user_id").val(),
		  	"password" : $("#password").val(),
		  },
		  error: function() {
	            $(".modal-body").html("Something is wrong");
		  		$("#messageModal").modal("show");
	       },
		  success: function(data) {
		  	if(data == "Duplicate") {
		  		$(".modal-body").html("This User ID cannot be use.");
		  		$("#messageModal").modal("show");
		  	}else{
		  		$(".modal-body").html("Register successfully");
		  		$("#messageModal").modal("show");
		  		$("#btn_message").click(function(){
		  			window.location.href = "<?=base_url()?>user/login";
		  		});
		  	}
		  }
		});
  	}
    
  });

});
</script>