<html>
	<head>
		<title>PhoneBook System</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    
	</head>
  <style>
    .error-text {
      border-color: red !important;
    }
    .navbar {
      background-color: #3D505A !important;
    }
    .user_name {
      line-height: 20px;
      padding: 15px 15px;
      display: block;
      position: relative;
      color:#9d9d9d;
    }
  </style>
  
	<body style="background-color: #D6EAF8;">
	<nav class="navbar navbar-inverse">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="<?php echo base_url(); ?>">PhoneBook System</a>
        </div>
        <div id="navbar">
          <ul class="nav navbar-nav">
            <li><a href="<?php echo base_url(); ?>">Home</a></li>
             <?php
          if(isset($_SESSION["user_name"])) {
            ?>
            <li><a href="<?php echo base_url(); ?>phone_list">Phone List</a></li>
            <li><a href="<?php echo base_url(); ?>phone_list/add">New Phone Book</a></li>
            <?php
          }
            ?>
          </ul>
          <?php
          if(isset($_SESSION["user_name"])) {
            ?>
            <ul class="nav navbar-nav navbar-right">
              <li><span class="user_name" >Hi <?= $_SESSION["user_name"]; ?></span></li>
              <li><a href="<?php echo base_url(); ?>user/logout">Logout</a></li>
            </ul>
            <?php
          }else{
            ?>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="<?php echo base_url(); ?>user/login">Login</a></li>
            </ul>
            <?php
          }
          ?>
        </div>
      </div>
    </nav>

<!-- Modal -->
<div class="modal fade" id="messageModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        Information
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <button id="btn_message" type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
    <div class="container">
      