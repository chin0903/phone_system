<h2><?= $title; ?></h2>
<p>Welcome to the home page, this is Phone Book System. Please click <a href="<?php echo base_url(); ?>user/login">here</a> to login to the system.</p>
<img src="<?php echo base_url(); ?>assets/image/phonebook.jpg" alt="" style="width:600px;">
